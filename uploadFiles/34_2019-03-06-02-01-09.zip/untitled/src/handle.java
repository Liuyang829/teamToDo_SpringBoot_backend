import com.alibaba.fastjson.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.sql.ResultSetMetaData;
import java.util.HashMap;
import java.io.File;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileNotFoundException;

public class handle {
    public static void main(String args[]) {
        MysqlConnection mysqlConnection= new MysqlConnection("jdbc:mysql://localhost:3306/test","root","zyh19980310");
        JsonHandler jsonhandler=new JsonHandler();
        jsonhandler.setMysqlLink(mysqlConnection);

        String taskID="20181213122924323";
        String username="test";

//        String json = "{\"msg\":\"调用成功\",\"code\":\"200\",\"data\":{\"message\":[{\"phone\":\"13799968400\",\"batchCode\":\"\",\"id\":\"130415\",\"state\":\"-99\"},{\"phone\":\"13815749444\",\"batchCode\":\"2166f10e9443\",\"id\":\"126417\",\"state\":\"1\"},{\"phone\":\"15100346866\",\"batchCode\":\"2166f14d7698\",\"id\":\"126418\",\"state\":\"1\"}]}}";
//        System.out.println("————————————————");
        File file = new File("./1.txt");
        String txt_str=txt2String(file);
//        System.out.println(txt_str);
//        System.out.println("————————————————");
        String[] str_list=txt_str.split("\n");
        for (int i = 0 ; i <str_list.length ; i++ ) {
            if(str_list[i].equals("")||str_list[i].equals("null")) continue;
            jsonhandler.handle(str_list[i],taskID,username);

        }


//
//        System.out.println(json);
////        解析json并写入数据库
//        jsonhandler.handle(json,taskID,username);

    }
    static String txt2String(File file){
        StringBuilder result = new StringBuilder();
        try{
            BufferedReader br = new BufferedReader(new FileReader(file));//构造一个BufferedReader类来读取文件
            String s = null;
            while((s = br.readLine())!=null){//使用readLine方法，一次读一行
                if(s.equals("")) continue;
//                System.out.println(s);
                result.append(System.lineSeparator()+s);
            }
            br.close();
        }catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch(Exception e){
            e.printStackTrace();
        }
        return result.toString();
    }
}

class JsonHandler{
    MysqlConnection mysqlConnection;
    void setMysqlLink(MysqlConnection mysqlConnection){
        this.mysqlConnection=mysqlConnection;
    }
    void handle(String json,String taskID,String username){
        JSONObject jobj_L1 = JSON.parseObject(json);
        String data_json = jobj_L1.getString("data");
        System.out.println(data_json);

        JSONObject jobj_L2 = JSON.parseObject(data_json);
        String message_jarr = jobj_L2.getString("message");
        System.out.println(message_jarr);

        int success_num=0;
        JSONArray jarr = JSON.parseArray(message_jarr);
        for (int i = 0, len = jarr.size(); i < len; i++) {
            JSONObject temp = jarr.getJSONObject(i);
            String state= temp.getString("state");
            String phone= temp.getString("phone");
            if (state.equals("1")){//统计成功个数
                success_num+=1;
                mysqlConnection.exec_sql("update detail set finalStatus = ? where taskID=? and tel=?",
                        state, taskID, phone);
            }else {
                mysqlConnection.exec_sql("update detail set finalStatus = ? where taskID=? and tel=?",
                        "0", taskID, phone);
            }
        }
//        System.out.println(success_num);

//        获取单价
        List l=mysqlConnection.exec_sql_query("select price from `userprice` where `username`=?",
                username);
        HashMap hm=(HashMap)l.get(0);
        float price=(float)hm.get("price");
//        System.out.println(price);
        mysqlConnection.exec_sql("update tasks set sucnum = ?,cost= ?,status= ? where taskID= ?",
                success_num,price*success_num,"已发送",taskID);

    }

}


class MysqlConnection{
    //声明Connection对象
    Connection con;
    //驱动程序名
    String driver = "com.mysql.jdbc.Driver";
    String url,user,password;
    Statement statement;
    MysqlConnection(String url,String user,String password){
        try {
            //加载驱动程序
            Class.forName(driver);
            //连接MySQL数据库
            con = DriverManager.getConnection(url,user,password);
            if(!con.isClosed()){
                System.out.println("Succeeded connecting to the Database!");
                this.url=url;
                this.user=user;
                this.password=password;
                this.statement=con.createStatement();
            }
        }catch(ClassNotFoundException e) {
            //数据库驱动类异常处理
            System.out.println("Sorry,can`t find the Driver!");
            e.printStackTrace();
        } catch(SQLException e) {
            //数据库连接失败异常处理
            e.printStackTrace();
        }catch (Exception e) {
            e.printStackTrace();
        }
    }
    //增删改
    void exec_sql(String sql,Object ...args){
        PreparedStatement psql;
        try{
            //预处理添加数据
            psql = con.prepareStatement(sql);

            for(int i=0,len=args.length; i<len; i++){
                psql.setObject(i+1, args[i]);
            }
//            System.out.println(psql);

            psql.executeUpdate();           //执行
        }catch(SQLException e) {
            //数据库连接失败异常处理
            e.printStackTrace();
        }
    }

    List exec_sql_query(String sql,Object ...args){
        PreparedStatement psql;
        List list = new ArrayList();
        try{
            psql = con.prepareStatement(sql);
            for(int i=0,len=args.length; i<len; i++){
                psql.setObject(i+1, args[i]);
            }
//            System.out.println(psql);

            ResultSet rs = psql.executeQuery();
            ResultSetMetaData md = rs.getMetaData();//获取键名
            int columnCount = md.getColumnCount();//获取行的数量
            while (rs.next()) {
                Map rowData = new HashMap();//声明Map
                for (int i = 1; i <= columnCount; i++) {
                    rowData.put(md.getColumnName(i), rs.getObject(i));//获取键名及值
                }
                list.add(rowData);
            }
            rs.close();
        }catch(SQLException e) {
            //数据库连接失败异常处理
            e.printStackTrace();
        }
        return list;
    }
}


